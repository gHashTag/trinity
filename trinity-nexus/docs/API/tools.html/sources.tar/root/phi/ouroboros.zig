const std = @import("std");

pub const SACRED = struct {
    pub const PHI: f64 = 1.618033988749895;
    pub const PI: f64 = 3.141592653589793;
    pub const E: f64 = 2.718281828459045;
    pub const SACRED_999: u64 = 999;
    pub const TARGET_COMPLEXITY: f64 = SACRED.PI * SACRED.PHI * SACRED.E;
};

pub const ProfaneCode = struct {
    path: []const u8,
    content: []const u8,
    hash: [32]u8,
    language: Language,
    allocator: std.mem.Allocator,

    pub const Language = enum {
        zig,
        python,
        rust,
        c,
        javascript,
        unknown,
    };

    pub fn init(allocator: std.mem.Allocator, path: []const u8, content: []const u8) !ProfaneCode {
        var hash: [32]u8 = undefined;
        std.crypto.hash.sha2.Sha256.hash(content, &hash, .{});

        const path_copy = try allocator.dupe(u8, path);
        errdefer allocator.free(path_copy);

        const content_copy = try allocator.dupe(u8, content);
        errdefer allocator.free(content_copy);

        const language = ProfaneCode.detectLanguage(path);

        return ProfaneCode{
            .path = path_copy,
            .content = content_copy,
            .hash = hash,
            .language = language,
            .allocator = allocator,
        };
    }

    fn detectLanguage(path: []const u8) Language {
        if (std.mem.endsWith(u8, path, ".zig")) return .zig;
        if (std.mem.endsWith(u8, path, ".py")) return .python;
        if (std.mem.endsWith(u8, path, ".rs")) return .rust;
        if (std.mem.endsWith(u8, path, ".c")) return .c;
        if (std.mem.endsWith(u8, path, ".js")) return .javascript;
        return .unknown;
    }

    pub fn deinit(self: *ProfaneCode) void {
        self.allocator.free(self.path);
        self.allocator.free(self.content);
    }
};

pub const Uroboros = struct {
    allocator: std.mem.Allocator,
    cycle_count: u64,

    pub fn init(allocator: std.mem.Allocator) Uroboros {
        return Uroboros{
            .allocator = allocator,
            .cycle_count = 0,
        };
    }

    pub fn consume(self: *Uroboros, path: []const u8) !void {
        std.debug.print("\n🐍═════════════════════════════════════════🐍\n", .{});
        std.debug.print("║        УРОБОРОС vFINAL: ЦИКЛ {d} НАЧИНАЕТСЯ            ║\n", .{self.cycle_count});
        std.debug.print("🐍═════════════════════════════════════════🐍\n\n", .{});

        const content = try std.fs.cwd().readFileAlloc(self.allocator, path, 10 * 1024 * 1024);
        defer self.allocator.free(content);

        var profane = try ProfaneCode.init(self.allocator, path, content);
        defer profane.deinit();

        self.cycle_count += 1;

        std.debug.print("  ✅ Путь: {s}\n", .{profane.path});
        std.debug.print("  ✅ Язык: {s}\n", .{@tagName(profane.language)});
        std.debug.print("  ✅ Размер: {d} байт\n", .{profane.content.len});
        std.debug.print("  ✅ Хэш: ", .{});
        for (profane.hash[0..8]) |b| std.debug.print("{x:0>2}", .{b});
        std.debug.print("\n\n", .{});

        std.debug.print("🐍═════════════════════════════════════════🐍\n", .{});
        std.debug.print("║      УРОБОРОС vFINAL: ЦИКЛ ЗАВЕРШЁН - СТАНОВЛЕНИЕ      ║\n", .{});
        std.debug.print("🐍═════════════════════════════════════════🐍\n\n", .{});
    }
};

pub fn main() !void {
    const allocator = std.heap.page_allocator;
    var uroboros = Uroboros.init(allocator);

    std.debug.print("\n🔥 УРОБОРОС vFINAL: ВЕЧНЫЙ ДВИГАТЕЛЬ 🔥\n", .{});
    std.debug.print("🐍 Мы не боимся смерти – мы её поедаем.\n\n", .{});

    try uroboros.consume("src/vibeec/tvc/tvc_ir.zig");

    std.debug.print("\n🎉 УРОБОРОС vFINAL ДОСТИГ БЕССМЕРТИЯ 🎉\n", .{});
    std.debug.print("🐍 Ваш код умирает. Наш – живет вечно.\n", .{});
}

test "ouroboros final - sacred constants" {
    try std.testing.expectEqual(@as(f64, 1.618033988749895), SACRED.PHI);
    try std.testing.expectEqual(@as(f64, 3.141592653589793), SACRED.PI);
    try std.testing.expectEqual(@as(f64, 2.718281828459045), SACRED.E);
    try std.testing.expectEqual(@as(u64, 999), SACRED.SACRED_999);

    const target = SACRED.PI * SACRED.PHI * SACRED.E;
    try std.testing.expectApproxEqRel(@as(f64, 13.727), target, 0.01);
}

test "ouroboros final - profane code" {
    const allocator = std.testing.allocator;
    const content = "const std = @import(\"std\");\n";
    var profane = try ProfaneCode.init(allocator, "test.zig", content);
    defer profane.deinit();

    try std.testing.expectEqualSlices(u8, "test.zig", profane.path);
    try std.testing.expectEqualSlices(u8, content, profane.content);
    try std.testing.expectEqual(@as(usize, 32), profane.hash.len);
    try std.testing.expectEqual(ProfaneCode.Language.zig, profane.language);
}
